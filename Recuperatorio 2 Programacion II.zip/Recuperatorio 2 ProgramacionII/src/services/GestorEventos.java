
package services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;


public class GestorEventos<T extends Evento> implements Gestable<T> {
    
    private List<T> eventos = new ArrayList<>();
    
    
    @Override
    public void limpiar(){
        eventos.clear();
    }
    
    @Override
    public void agregar(T evento) {
        eventos.add(evento);
    }

    @Override
    public T obtener(int indice){
        return eventos.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        eventos.remove(indice);
    }

    @Override
    public List filtrar(Predicate<T> predicado) {
       List<T> toReturn = new ArrayList<>();
       
       for (T item : eventos){
            if (predicado.test(item)){
                   toReturn.add(item);
            }
       }
               return toReturn;
    }

    @Override
    public List<T> buscarPorRango(LocalDate inicio, LocalDate fin) {
    List<T> eventosEnRango = new ArrayList<>();
    
    for (T evento : eventos) {
        LocalDate fechaEvento = evento.getFecha();
        if (fechaEvento.compareTo(inicio) >= 0 && fechaEvento.compareTo(fin) <= 0) {
            eventosEnRango.add(evento);
        }
    }
    return eventosEnRango;
    }
    
    @Override
    public void ordenar() {
       ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    
    @Override
    public void ordenar(Comparator<T> comparador) {
      eventos.sort(comparador);
    }

 @Override
    public void guardarBinario(String path) {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))){
                
            oos.writeObject(eventos);
        
        
        
        }  catch (IOException ex) {
                System. out.println (ex.getMessage ());
                        }
    }

    @Override
    public void cargarBinario(String path) {
       try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))){
           
           eventos = (List<T>) ois.readObject();
       
       
       } catch (IOException | ClassNotFoundException ex) {
                System. out.println (ex.getMessage ());
                        }
    }

    @Override
    public void guardarCSV(String path) {
         try(BufferedWriter bw = new BufferedWriter(new FileWriter(path ))){
        
         bw.write("id, nombre, fecha, artista, genero\n");
         
         for (T item : eventos){
             bw.write(item.toCSV() + "\n");
         }
     } catch(IOException ex){
            System.out.println(ex.getMessage());
            throw new  RuntimeException("Ha habido un error con el archivo.");
        }
    }

    @Override
     public void cargarCSV(String path, Function<String, T> funcion) {
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            String linea;
            
            br.readLine();
            while ((linea = br.readLine()) != null){
               T objeto = funcion.apply(linea);
               if(!eventos.contains(objeto)){
                   eventos.add(objeto);
               }
                
            }
        
        } catch(IOException ex){
            System.out.println(ex.getMessage());
            throw new  RuntimeException("Ha habido un error con el archivo.");
        }
    }

     @Override
    public void mostrarTodos(Consumer<T> consumer) {
       eventos.forEach(consumer);
    }
    
    @Override
    public T buscarPorIndice(int indice) {
        if (indice >= 0 && indice < eventos.size()) {
            return eventos.get(indice);
        } else {
            System.out.println("Índice fuera de rango");
            return null;
        }
    }
    
}

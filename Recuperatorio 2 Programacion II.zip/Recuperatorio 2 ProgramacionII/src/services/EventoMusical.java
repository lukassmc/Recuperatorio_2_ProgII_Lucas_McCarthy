
package services;


import java.time.LocalDate;
import java.util.Objects;
import model.Evento;
import model.GenerosMusicales;

public class EventoMusical extends Evento implements Comparable<EventoMusical>{
   
   
    private String artista_principal;
    private GenerosMusicales genero_musical;

    public EventoMusical(int id, String nombre, LocalDate fecha,String artista_principal, GenerosMusicales genero_musical  ) {
        super(id, nombre, fecha);
        this.artista_principal = artista_principal;
        this.genero_musical = genero_musical;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EventoMusical other = (EventoMusical) obj;
        if (!Objects.equals(this.artista_principal, other.artista_principal)) {
            return false;
        }
        return this.genero_musical == other.genero_musical;
    }

    public String getArtista_principal() {
        return artista_principal;
    }

    public GenerosMusicales getGenero_musical() {
        return genero_musical;
    }

    
    
    @Override
    public int compareTo(EventoMusical o) {
        if (o == null) {
        throw new NullPointerException("El evento comparado no puede ser null");
    }
        return this.getFecha().compareTo(o.getFecha());
    }
 
    public static EventoMusical fromCSV(String eventoMusicalCSV){
       if (eventoMusicalCSV.endsWith ("\n") ) {
            eventoMusicalCSV = eventoMusicalCSV.substring(0, eventoMusicalCSV.length () - 1);
       }
        if (eventoMusicalCSV.endsWith("\n")) {
            eventoMusicalCSV = eventoMusicalCSV.substring(0, eventoMusicalCSV.length() - 1);
        }
        String[] data = eventoMusicalCSV.split(",");
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    LocalDate fecha = LocalDate.parse(data[2]);
                    String artista = data[3];
                    GenerosMusicales genero =GenerosMusicales.valueOf(data[4]);

                   return new EventoMusical(id, nombre, fecha, artista, genero);
            }

    @Override
    public String toString(){
        return super.toString() + "," + artista_principal + "," + genero_musical;
    
    }
    
    @Override
    public String toCSV(){
        return super.toCSV() + "," + artista_principal + "," + genero_musical; 
    }
    
   }
    
    
    



package Main;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import model.GenerosMusicales;
import services.EventoMusical;
import services.GestorEventos;
import config.AppConstants;

public class Recuperatorio2ProgramacionII {


    public static void main(String[] args) {
        // Crear instancia del gestor de eventos
GestorEventos<EventoMusical> gestor = new GestorEventos<>();
// Crear algunos eventos musicales
gestor.agregar(new EventoMusical(1, "Rock Fest", LocalDate.of(2024, 3, 15),
"Queen Revival", GenerosMusicales.ROCK));
gestor.agregar(new EventoMusical(2, "Jazz Night", LocalDate.of(2024, 6, 20),
"John Doe Quintet", GenerosMusicales.JAZZ));
gestor.agregar(new EventoMusical(3, "Pop Party", LocalDate.of(2024, 8, 5),
"Taylor Tribute", GenerosMusicales.POP));
gestor.agregar(new EventoMusical(4, "Electronic Vibes", LocalDate.of(2024, 10,
12), "DJ Nova", GenerosMusicales.ELECTRONICA));


// Mostrar todos los eventos
System.out.println("Lista inicial de eventos:");
gestor.mostrarTodos(evento -> System.out.println(evento.toString()));


// Ordenar por fecha (orden natural)
System.out.println("\nEventos ordenados por fecha:");
gestor.ordenar();
gestor.mostrarTodos(evento -> System.out.println(evento.toString()));


// Ordenar por nombre de evento
System.out.println("\nEventos ordenados por nombre:");
gestor.ordenar((e1, e2) -> e1.getNombre().compareTo(e2.getNombre()));
gestor.mostrarTodos(evento -> System.out.println(evento.toString()));


// Filtrar por género
System.out.println("\nEventos de genero ROCK:");
List<EventoMusical> rockEvents = gestor.filtrar(e -> e.getGenero_musical().equals(GenerosMusicales.ROCK));
rockEvents.forEach(System.out::println);


// Filtrar por palabra clave en el nombre
System.out.println("\nEventos que contienen 'Night' en el nombre:");
List<EventoMusical> nightEvents = gestor.filtrar(e -> e.getNombre().contains("Night"));
nightEvents.forEach(System.out::println);


// Buscar por rango de fechas
System.out.println("\nEventos entre el 01/01/2024 y el 31/07/2024:");
List<EventoMusical> dateRangeEvents = gestor.buscarPorRango(
LocalDate.of(2024, 1, 1),
LocalDate.of(2024, 7, 31)
);
dateRangeEvents.forEach(System.out::println);


// Guardar y cargar en formato binario
System.out.println("\nGuardando y cargando eventos en binario...");
gestor.guardarBinario(AppConstants.SERIAL.toString());
gestor.limpiar(); // Vaciar el gestor
gestor.cargarBinario(AppConstants.SERIAL.toString());
gestor.mostrarTodos(evento -> System.out.println(evento.toString()));
// Guardar y cargar en formato CSV
System.out.println("\nGuardando y cargando eventos en CSV...");
gestor.guardarCSV(AppConstants.CSV.toString());


gestor.limpiar(); // Vaciar el gestor
gestor.cargarCSV(AppConstants.CSV.toString(), linea
                    -> EventoMusical.fromCSV(linea));
gestor.mostrarTodos(evento -> System.out.println(evento.toString()));



// Filtro dinámico usando Predicate
System.out.println("\nFiltrar eventos dinamicamente (artista contiene 'DJ'):");
Predicate<EventoMusical> filtroArtista = (e -> e.getArtista_principal().contains("DJ"));
List<EventoMusical> filtroDinamico = gestor.filtrar(filtroArtista);
filtroDinamico.forEach(System.out::println);


// Eliminar un evento
        System.out.println("\nEliminando evento en indice 2...");
        gestor.eliminar(2);

        // Mostrar la lista despues de la eliminacion
        System.out.println("\nLista de eventos despues de eliminar:");
        gestor.mostrarTodos(evento -> System.out.println(evento.toString()));

        // Obtener un evento por indice
        System.out.println("\nObteniendo evento en el indice 1...");
        EventoMusical eventoObtenido = (EventoMusical) gestor.obtener(1);  
        if (eventoObtenido != null) {
            System.out.println("Evento obtenido: " + eventoObtenido);
        }

    }
    
}

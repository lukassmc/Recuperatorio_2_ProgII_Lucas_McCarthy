
package model;

public enum GenerosMusicales {
    ROCK, 
    POP, 
    JAZZ, 
    CLASICA, 
    ELECTRONICA
}

